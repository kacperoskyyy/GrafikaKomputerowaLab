function uvPyramid(height, side, slices) {
    height = height || 5.0; 
    side = side || 5.0; 
    slices = slices || 12;

    var vertexCount = (slices + 1) * 2 + 1; // Added 1 for the base
    var triangleCount = slices * 4 + slices; // Added slices for the base

    var vertices = new Float32Array(vertexCount * 3);
    var normals = new Float32Array(vertexCount * 3);
    var texCoords = new Float32Array(vertexCount * 2);
    var indices = new Uint16Array(triangleCount * 3);

    var halfSide = side / 2.0;
    var kv = 0;
    var kt = 0;
    var k = 0;
    var i, u;

    // Vertex and normal for the apex
    vertices[kv] = 0;
    normals[kv++] = 0;
    vertices[kv] = height;
    normals[kv++] = 1;
    vertices[kv] = 0;
    normals[kv++] = 0;
    texCoords[kt++] = 0.5;
    texCoords[kt++] = 0.5;

    for (i = 0; i < slices; i++) {
        u = i * 2 * Math.PI / slices;
        var nextU = (i + 1) * 2 * Math.PI / slices;
        var c = Math.cos(u);
        var s = Math.sin(u);
        var nextC = Math.cos(nextU);
        var nextS = Math.sin(nextU);
        
        // Base vertices
        vertices[kv] = halfSide * c;
        normals[kv++] = 0;
        vertices[kv] = 0;
        normals[kv++] = -1;
        vertices[kv] = halfSide * s;
        normals[kv++] = 0;
        texCoords[kt++] = (c + 1) / 2;
        texCoords[kt++] = (s + 1) / 2;

        // Side vertices
        vertices[kv] = halfSide * nextC;
        normals[kv++] = 0;
        vertices[kv] = 0;
        normals[kv++] = -1;
        vertices[kv] = halfSide * nextS;
        normals[kv++] = 0;
        texCoords[kt++] = (nextC + 1) / 2;
        texCoords[kt++] = (nextS + 1) / 2;

        // Triangle indices for sides
        indices[k++] = 0;
        indices[k++] = i * 2 + 1;
        indices[k++] = ((i + 1) % slices) * 2 + 1;

        indices[k++] = i * 2 + 1;
        indices[k++] = i * 2 + 2;
        indices[k++] = ((i + 1) % slices) * 2 + 2;

        indices[k++] = i * 2 + 1;
        indices[k++] = ((i + 1) % slices) * 2 + 2;
        indices[k++] = ((i + 1) % slices) * 2 + 1;

        // Triangle indices for base
        indices[k++] = vertexCount - 1;
        indices[k++] = i * 2 + 1;
        indices[k++] = ((i + 1) % slices) * 2 + 1;
    }

    return {
        vertexPositions: vertices,
        vertexNormals: normals,
        vertexTextureCoords: texCoords,
        indices: indices
    };
}

var pyramid = uvPyramid(); // Added this line to define the pyramid

function drawModel(model) {
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_DEPTH_TEST);

    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, model.vertexPositions);
    glEnableClientState(GL_NORMAL_ARRAY);
    glNormalPointer(GL_FLOAT, 0, model.vertexNormals);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FLOAT, 0, model.vertexTextureCoords);
    
    var halfSide = side / 2.0;
    var maxHeight = Math.max.apply(null, model.vertexPositions);
    var centeringFactor = maxHeight / 2.0;
    
    glPushMatrix();
    glTranslatef(-halfSide, -centeringFactor, -halfSide); // Translate to center
    glDrawElements(GL_TRIANGLES, model.indices.length, GL_UNSIGNED_SHORT, model.indices);
    glPopMatrix();
    
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);

    glDisable(GL_LIGHTING);
    glDisable(GL_LIGHT0);
    glDisable(GL_NORMALIZE);
    glDisable(GL_DEPTH_TEST);
}
